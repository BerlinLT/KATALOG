<p align="center">
    <a href="https://app.codacy.com/gh/mrismanaziz/Man-Userbot/dashboard"> <img src="https://img.shields.io/codacy/grade/a8f0747a964e4712818a28d2a7f4edd3?color=blue&logo=codacy&style=for-the-badge" alt="Codacy" /></a>
    <a href="https://github.com/mrismanaziz/Man-Userbot"> <img src="https://img.shields.io/github/repo-size/mrismanaziz/Man-Userbot?logo=github&style=for-the-badge" /></a>
    <a href="https://github.com/mrismanaziz/Man-Userbot/network/members"> <img src="https://img.shields.io/github/forks/mrismanaziz/Man-Userbot?logo=github&style=for-the-badge" /></a>
    <a href="https://pypi.org/project/Telethon/"> <img src="https://img.shields.io/pypi/v/telethon?label=telethon&logo=pypi&logoColor=white&style=for-the-badge" /></a>
    <img alt="PYTHON" src="https://img.shields.io/badge/PYTHON-v3.9.0-blue?style=for-the-badge&logo=appveyor"/>
   </p>


<h3 align="center">A modular Telegram userbot running on Python 3.9+ with an sqlalchemy database.</h3>
<p align="center">&nbsp;</p>

# Based on RaphielGang's [Telegram-Paperplane](https://github.com/RaphielGang/Telegram-Paperplane)

```
/**
    Your Telegram account may get banned.
    I am not responsible for any improper use of this bot
    This bot is intended for the purpose of having fun with memes,
    as well as efficiently managing groups.
    You ended up spamming groups, getting reported left and right,
    and you ended up in a Finale Battle with Telegram and at the end
    Telegram Team deleted your account?
    And after that, then you pointed your fingers at us
    for getting your acoount deleted?
    I will be rolling on the floor laughing at you.
/**
```
### Repo Man-UserBot
Repo Yang Dibuat Berbagai Repo Userbot Github dan di Recode Oleh [Risman](https://t.me/mrismanaziz)

## Generate String Session

### Run on repl.it

Gabung Ke [Grup Support](https://t.me/sharinguserbot) Man-UserBot Lalu Ketik #string [TEKAN DISINI](https://t.me/sharinguserbot) Untuk Masuk Ke [Grup Support](https://t.me/sharinguserbot)
<br>

## Cara Deploy 👷

```
* **[HEROKU](https://www.heroku.com/) Method** 🔧

  > Pertama, dapatkan API_KE & API_HASH di my.telegram.org (wajib)

  > Dapatkan Sesi String pada perintah di bawah ini, jalankan di terminal Anda (wajib)

  > Selanjutnya klik Deploy tombol di bawah ini.

  > Isi bidang vars wajib di heroku

  > Akhirnya nyalakan aplikasi dan periksa log (pengaturan -> lihat log) enjoyy :)
```

## <p align="center">Deploy to Heroku Methods</p>


<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/mrismanaziz/Man-Userbot"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blue?style=flat&logo=heroku" width="210" height="34.45" /></a></p>

<br>

## Credits
*   [RaphielGang](https://github.com/RaphielGang) - Telegram-Paperplane
*   [AvinashReddy3108](https://github.com/AvinashReddy3108) - PaperplaneExtended
*   [Mkaraniya](https://github.com/mkaraniya) & [Dev73](https://github.com/Devp73) - OpenUserBot
*   [Mr.Miss](https://github.com/keselekpermen69) - UserButt
*   [adekmaulana](https://github.com/adekmaulana) - ProjectBish
*   [MoveAngel](https://github.com/MoveAngel) - One4uBot
*   [AidilAryanto](https://github.com/aidilaryanto) - ProjectDils 
*   [Alfianandaa](https://github.com/alfianandaa/ProjectAlf) - ProjectAlf
*   [AnggaR69s](https://github.com/GengKapak/DCLXVI) - DCLXVI
*   [BianSepang](https://github.com/BianSepang/WeebProject) - WeebProject
*   [TeamUserge](https://github.com/UsergeTeam/Userge) - Userge
*   [Lord-Userbot](https://github.com/Zora24/Lord-Userbot) - Alvin
*   [Kampang-Bot](https://github.com/ManusiaRakitan/Kampang-Bot) - Koala
*   [X-REMIX](https://github.com/ximfine) -  X_ImFine
*   [Man-Userbot](https://github.com/mrismanaziz/Man-Userbot) -  Risman
*   AND OTHER
